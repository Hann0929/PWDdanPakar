<?php
// Aktifkan reporting error untuk debugging
error_reporting(E_ALL); 
ini_set('display_errors', 1);

// =======================================
// 1. SETUP & KONEKSI DATABASE
// =======================================

// Deteksi lokasi file koneksi.php
include "db/koneksi.php"; 

// Cek koneksi setelah include. Jika gagal, die() sudah diaktifkan di koneksi.php.
// Baris ini berfungsi sebagai pengecekan akhir:
if (!isset($conn) || mysqli_connect_errno()) {
    die("ERROR: Variabel \$koneksi tidak ditemukan atau koneksi gagal.");
}


// =================================================
// 2. FUNGSI: MENGAMBIL ATURAN (RULES) DARI DATABASE
// =================================================

function getRulesFromDatabase($conn): array {
    $rules = [];

    // Ambil kondisi
    $sql_conditions = "
        SELECT 
            rb.rule_id,
            g.attribute_key,
            rc.expected_value
        FROM rule_base rb
        JOIN rule_condition rc ON rb.rule_id = rc.rule_id
        JOIN gejala g ON rc.gejala_id = g.gejala_id
        ORDER BY rb.rule_id;
    ";

    $result_conditions = mysqli_query($conn, $sql_conditions);
    if (!$result_conditions) {
        die('Query Kondisi Gagal: ' . mysqli_error($conn));
    }

    while ($row = mysqli_fetch_assoc($result_conditions)) {
        if (!isset($rules[$row['rule_id']])) {
            $rules[$row['rule_id']] = [
                'conditions' => [],
                'conclusions' => []
            ];
        }
        $rules[$row['rule_id']]['conditions'][] = [
            'attribute_key' => $row['attribute_key'],
            'expected_value' => $row['expected_value']
        ];
    }

    // Ambil kesimpulan (hero yg direkomendasikan)
    $sql_conclusions = "
        SELECT
            rc.rule_id,
            h.name AS hero_name
        FROM rule_conclusion rc
        JOIN hero h ON rc.hero_id = h.hero_id
        ORDER BY rc.rule_id;
    ";

    $result_conclusions = mysqli_query($conn, $sql_conclusions);
    if (!$result_conclusions) {
        die('Query Kesimpulan Gagal: ' . mysqli_error($conn));
    }

    while ($row = mysqli_fetch_assoc($result_conclusions)) {
        if (!isset($rules[$row['rule_id']])) {
            $rules[$row['rule_id']] = [
                'conditions' => [],
                'conclusions' => []
            ];
        }
        $rules[$row['rule_id']]['conclusions'][] = [
            'hero_name' => $row['hero_name']
        ];
    }

    return $rules;
}

// =================================================
// 3. FUNGSI INTI: FORWARD CHAINING
// =================================================
function forwardChain(array $facts, $conn): array {

    $rules = getRulesFromDatabase($conn);
    $currentFacts = $facts;
    $firedRules = [];
    $newFactsAdded = true;

    while ($newFactsAdded) {
        $newFactsAdded = false;

        foreach ($rules as $ruleId => $rule) {

            if (in_array($ruleId, $firedRules)) {
                continue;
            }

            $conditionsMet = true;

            foreach ($rule['conditions'] as $condition) {
                $factKey       = $condition['attribute_key'];
                $requiredValue = $condition['expected_value'];

                // Cek apakah fakta ada DAN nilainya cocok
                if (!isset($currentFacts[$factKey]) || $currentFacts[$factKey] !== $requiredValue) {
                    $conditionsMet = false;
                    break;
                }
            }

            if ($conditionsMet) {
                $factName = 'final_hero_recommendation';

                foreach ($rule['conclusions'] as $conclusion) {
                    $heroName = $conclusion['hero_name'];

                    if (!isset($currentFacts[$factName]) || !is_array($currentFacts[$factName])) {
                        $currentFacts[$factName] = [];
                    }

                    if (!in_array($heroName, $currentFacts[$factName])) {
                        $currentFacts[$factName][] = $heroName;
                        $newFactsAdded = true;
                    }
                }

                $firedRules[] = $ruleId;
            }
        }
    }

    $currentFacts['triggered_rules'] = $firedRules;
    return $currentFacts;
}


// ====================================================
// 4. PROSES UTAMA: AKSES DATA POST
// ====================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jawaban'])) {

    // 1. Proses dan Validasi Input Jawaban
    $inputJawaban = $_POST['jawaban'];
    $validFacts   = [];

    foreach ($inputJawaban as $key => $value) {
        // Kunci ($key) adalah attribute_key dari tabel gejala
        if (!empty($value) && $value !== '-- pilih jawaban --') {
            $validFacts[$key] = $value;
        }
    }

    if (empty($validFacts)) {
        header("Location: diagnosa.php?error=no_input");
        exit;
    }

    // 2. Jalankan forward chaining
    $finalDiagnosis = forwardChain($validFacts, $conn); // $koneksi dilewatkan

    // 3. Persiapan Data Hasil
    $recommendedHeroes = $finalDiagnosis['final_hero_recommendation'] ?? [];
    $triggeredRules    = $finalDiagnosis['triggered_rules'] ?? [];

    $heroList = empty($recommendedHeroes)
        ? 'Tidak ada hero yang direkomendasikan berdasarkan jawaban Anda.'
        : implode(" / ", $recommendedHeroes);

    $triggerRuleList = empty($triggeredRules)
        ? 'Tidak ada'
        : implode(", ", $triggeredRules);


    // =============================
    // 4. TAMPILAN HASIL HTML
    // =============================
    echo "
    <!DOCTYPE html>
    <html lang='id'>
    <head>
        <meta charset='UTF-8'>
        <title>Hasil Diagnosa</title>
        <link rel='stylesheet' href='../css/diagnosa.css'>
        <style>
            .container { max-width: 800px; margin: 40px auto; padding: 20px; border: 1px solid #ccc; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
            .result-box { margin-top: 20px; padding: 15px; border: 2px solid #007bff; background-color: #e3f2fd; border-radius: 5px; }
            pre { background: #f9f9f9; padding: 10px; border: 1px solid #ddd; white-space: pre-wrap; word-wrap: break-word; }
            .btn { display: inline-block; padding: 10px 15px; background-color: #4CAF50; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <h2>Hasil Rekomendasi Hero</h2>

            <div class='result-box'>
                <h3>Rekomendasi Hero:</h3>
                <p style='font-size:20px; font-weight:bold; color:#007bff;'>{$heroList}</p>
            </div>

            <h3>Aturan yang Terpicu:</h3>
            <p>{$triggerRuleList}</p>

            <h3>Jawaban Anda:</h3>
            <pre>" . print_r($validFacts, true) . "</pre>

            <h3>Semua Fakta Sistem (Diagnosis Lengkap):</h3>
            <pre>" . print_r($finalDiagnosis, true) . "</pre>

            <a href='diagnosa.php' class='btn'>← Kembali ke Diagnosa</a>
        </div>
    </body>
    </html>
    ";

} else {
    // Jika diakses langsung tanpa POST
    header("Location: diagnosa.php");
    exit;
}
?>