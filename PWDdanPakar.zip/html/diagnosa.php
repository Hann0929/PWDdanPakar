<?php
// Pastikan koneksi terbaca
include "db/koneksi.php";

// Simpan koneksi ke variabel
$koneksi = $conn;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diagnosa Hero MLBB</title>
    <link rel="stylesheet" href="../css/diagnosa.css">
</head>
<body>

<div class="container">
    <h2>Diagnosa Pemilihan Hero MLBB</h2>
    <p class="desc">Jawablah pertanyaan berikut untuk mendapatkan rekomendasi hero terbaik untuk Anda.</p>

    <form method="POST" action="proses.php">

    <?php
    // --- QUERY GEJALA / PERTANYAAN ---
    $query_gejala = "SELECT gejala_id, pertanyaan, attribute_key FROM gejala ORDER BY gejala_id ASC";
    $result_gejala = mysqli_query($koneksi, $query_gejala);

    if (!$result_gejala) {
        die("Query Gagal: " . mysqli_error($koneksi));
    }

    while ($row_gejala = mysqli_fetch_assoc($result_gejala)) {

        echo "<div class='box'>";
        echo "<p class='question'><b>".$row_gejala['pertanyaan']."</b></p>";

        // opsi jawaban berdasarkan attribute_key
        $attribute_key = $row_gejala['attribute_key'];
        $options = [];

        if (strpos($attribute_key, 'low') !== false || strpos($attribute_key, 'high') !== false) {
            $options = ["yes", "no"];
        } 
        elseif ($attribute_key == 'preferred_role') {
            $options = ["ranged", "melee"];
        } 
        elseif ($attribute_key == 'team_needs' || $attribute_key == 'team_needs_role') {
            $options = ["crowd_control", "burst_damage", "anti_tank", "mid_lane", "exp_lane", "roamer"];
        } 
        else {
            $options = ["yes", "no", "low", "medium", "high"];
        }

        echo "<select name='jawaban[".$attribute_key."]' class='select' required>";
        echo "<option value=''>-- pilih jawaban --</option>";

        foreach ($options as $op) {
            echo "<option value='$op'>$op</option>";
        }

        echo "</select>";
        echo "</div>";
    }
    ?>

    <button type="submit" class="btn">Proses Diagnosa</button>

    </form>
</div>

</body>
</html>
