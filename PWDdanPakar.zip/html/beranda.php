<?php
include "db/koneksi.php";
?>
<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sistem Pakar Hero MLBB</title>
  <link rel="stylesheet" href="../css/beranda.css">
</head>
<body>
  <nav class="navbar">
    <div class="logo">
      <img src="../assets/logo.png" alt="MLBB Logo">
      <span>MLBB TIER</span>
    </div>
    <ul>
      <li><a href="#" class="active">Beranda</a></li>
      <li><a href="analisis.php">Analisis</a></li>
      <li><a href="diagnosa.php">Diagnosa</a></li>
      <li><a href="informasi.php">informasi</a></li>
    
    </ul>
  </nav>
 
  <section class="hero-section">
    <div class="content">
      <h1>Selamat Datang, Challenger!</h1>
      <p>Temukan hero terbaikmu dan dominasi Land of Dawn dengan sistem pakar MLBB kami.</p>
      <a href="analisis.php" class="btn">Analisis counter</a>
      <a href="diagnosa.php" class="btn btn-secondary">Diagnosa Hero</a>
    </div>
    <div class="image">
      <img src="../assets/selena2.png" alt="MLBB Hero">
    </div>
  </section>

  <section class="about-section">
  <h2>Tentang Pembuatan Build Mobile Legends</h2>

  <div class="about-content">
    <div class="about-left">
      <h3>Mengapa Menggunakan MoleBuild?</h3>
      <p>
        MoleBuild adalah platform terbaik bagi pemain Mobile Legends: Bang Bang untuk membuat, berbagi, dan menemukan strategi kemenangan.
        Pembuat build kami yang komprehensif memungkinkan Anda bereksperimen dengan kombinasi item, konfigurasi emblem, dan pemilihan battle spell.
      </p>
    </div>

    <div class="about-right">
      <h3>Fitur Utama</h3>
      <p>
        <strong>Pembuat Build</strong> yang komprehensif dengan semua item dan emblem<br>
        <strong>Bandingkan Build</strong> untuk menganalisis berbagai strategi<br>
        Statistik hero yang detail dan informasi peran<br>
        Simpan dan atur build favorit Anda<br>
        Bagikan build dengan teman dan rekan tim
      </p>
    </div>
  </div>
</section>
<footer class="footer">
    <div class="footer-left">
        <a href="#">Kebijakan Privasi</a>  |  
        <a href="#">Syarat Layanan</a>
        <p>Hubungi Kami < mobilelegendsgame@moonton.com ></p>
        <p>© Moonton. All rights reserved</p>
    </div>

    <div class="footer-right">
        <a href="#" class="icon"><i class="fab fa-facebook-f"></i></a>
        <a href="#" class="icon"><i class="fab fa-x-twitter"></i></a>
        <a href="#" class="icon"><i class="fab fa-instagram"></i></a>
        <a href="#" class="icon"><i class="fab fa-tiktok"></i></a>
        <a href="#" class="icon"><i class="fab fa-youtube"></i></a>
        <a href="#" class="icon"><i class="fas fa-globe"></i></a>
    </div>
</footer>
</body>
</html>
