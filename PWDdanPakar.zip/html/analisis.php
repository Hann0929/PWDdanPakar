<?php
include"koneksi.php";
?>
<link rel="stylesheet" href="../css/analisis.css">
<script src="../js/analisis.js"></script>

<div class="hero-container">

  <div class="hero-card">
    <img src="img/obsidia.jpg" alt="Obsidia">
    <p>Obsidia</p>
  </div>

  <div class="hero-card">
    <img src="img/zetian.jpg" alt="Zetian">
    <p>Zetian</p>
  </div>

  <div class="hero-card">
    <img src="img/kalea.jpg" alt="Kalea">
    <p>Kalea</p>
  </div>

  <div class="hero-card">
    <img src="img/lukas.jpg" alt="Lukas">
    <p>Lukas</p>
  </div>

  <div class="hero-card">
    <img src="img/suyou.jpg" alt="Suyou">
    <p>Suyou</p>
  </div>

  <div class="hero-card">
    <img src="img/zhuxin.jpg" alt="Zhuxin">
    <p>Zhuxin</p>
  </div>

  <div class="hero-card">
    <img src="img/chip.jpg" alt="Chip">
    <p>Chip</p>
  </div>

</div>
