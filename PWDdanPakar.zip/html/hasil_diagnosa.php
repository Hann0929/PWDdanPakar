<?php
session_start();

if (!isset($_SESSION['diagnosa'])) {
    header("Location: diagnosa.php");
    exit;
}

$finalDiagnosis   = $_SESSION['diagnosa'];
$validFacts       = $_SESSION['jawaban'];

$recommendedHeroes = $finalDiagnosis['final_hero_recommendation'] ?? [];
$triggeredRules    = $finalDiagnosis['triggered_rules'] ?? [];

$heroList = empty($recommendedHeroes)
    ? 'Tidak ada hero yang direkomendasikan.'
    : implode(" / ", $recommendedHeroes);

$triggerRuleList = empty($triggeredRules)
    ? 'Tidak ada'
    : implode(", ", $triggeredRules);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hasil Diagnosa</title>
    <link rel="stylesheet" href="../css/proses.css">>
</head>
<body>
    <div class="container">

        <h2>Hasil Rekomendasi Hero</h2>

        <div class="result-box">
            <h3>Rekomendasi Hero:</h3>
            <p class="hero"><?= $heroList ?></p>
        </div>

        <h3>Aturan yang Terpicu:</h3>
        <p><?= $triggerRuleList ?></p>

        <h3>Jawaban Anda:</h3>
        <pre><?php print_r($validFacts); ?></pre>

        <h3>Semua Fakta Sistem (Diagnosis Lengkap):</h3>
        <pre><?php print_r($finalDiagnosis); ?></pre>

        <a href="diagnosa.php" class="btn">← Kembali ke Diagnosa</a>
    </div>
</body>
</html>
